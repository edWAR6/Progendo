//______________________
//______________________
//
// GLOBAL ID'S
//
//______________________
//______________________

var APP_ID = "7";
var SYNC_SERVER_URL = "http://servicios.cfrcenam.mobi/CFRService.svc/Sync-iPad";

//______________________
//______________________
//
// SCREEN ID'S
//
//______________________
//______________________
var SYNC_SCREEN_ID				= "1600";
var INDEX_SCREEN_ID 			= "1601";
var DOLOR_SCREEN_ID 			= "1602";
var DOLORCRONICO1_SCREEN_ID 	= "1603";
var DOLORCRONICO2_SCREEN_ID 	= "1604";
var DOLORCRONICO3_SCREEN_ID 	= "1605";
var PSIQUIATRIA_SCREEN_ID 		= "1606";
var PSIQUIATRIAVIDEOS_SCREEN_ID = "1607";
var VIDEO1_SCREEN_ID 			= "1608";
var VIDEO2_SCREEN_ID 			= "1609";
var ESQUEMATITULACION_SCREEN_ID = "1610";
var TITULACION1_SCREEN_ID 		= "1611";
var TITULACION2_SCREEN_ID 		= "1612";

//______________________
//______________________
//
// ACTION ID'S
//
//______________________
//______________________

var APP_CONFIG_ACTION_SCREEN_OPEN 	= "PA";//pantalla abierta
var APP_CONFIG_ACTION_SCREEN_CLICK	= "BP";//boton presionado
var APP_CONFIG_ACTION_APP_MINIMIZED = "AM";//application minimizada
var APP_CONFIG_ACTION_SYNC_CLICK 	= "SYNC";//synchronize button click

var GO_TO_SYNC_SCREEN				= "GOTO_"+SYNC_SCREEN_ID;
var GO_TO_INDEX_SCREEN				= "GOTO_"+INDEX_SCREEN_ID;
var GO_TO_DOLOR_SCREEN				= "GOTO_"+ DOLOR_SCREEN_ID;
var GO_TO_DOLORCRONICO1_SCREEN		= "GOTO_"+ DOLORCRONICO1_SCREEN_ID;
var GO_TO_DOLORCRONICO2_SCREEN		= "GOTO_"+ DOLORCRONICO2_SCREEN_ID;
var GO_TO_DOLORCRONICO3_SCREEN		= "GOTO_"+ DOLORCRONICO3_SCREEN_ID;
var GO_TO_PSIQUIATRIA_SCREEN		= "GOTO_"+ PSIQUIATRIA_SCREEN_ID;
var GO_TO_PSIQUIATRIAVIDEOS_SCREEN	= "GOTO_"+ PSIQUIATRIAVIDEOS_SCREEN_ID;
var GO_TO_VIDEO1_SCREEN				= "GOTO_"+ VIDEO1_SCREEN_ID;
var GO_TO_VIDEO2_SCREEN				= "GOTO_"+ VIDEO2_SCREEN_ID;
var GO_TO_ESQUEMATITULACION_SCREEN	= "GOTO_"+ ESQUEMATITULACION_SCREEN_ID;
var GO_TO_TITULACION1_SCREEN		= "GOTO_"+ TITULACION1_SCREEN_ID;
var GO_TO_TITULACION2_SCREEN		= "GOTO_"+ TITULACION2_SCREEN_ID;